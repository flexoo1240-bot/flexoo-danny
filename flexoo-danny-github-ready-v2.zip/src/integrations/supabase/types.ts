export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.15"
  }
  public: {
    Tables: {
      app_settings: {
        Row: {
          key: string
          updated_at: string
          value: string | null
        }
        Insert: {
          key: string
          updated_at?: string
          value?: string | null
        }
        Update: {
          key?: string
          updated_at?: string
          value?: string | null
        }
        Relationships: []
      }
      community_channels: {
        Row: {
          created_at: string
          description: string | null
          display_order: number
          icon: string | null
          id: string
          member_count: string | null
          name: string
          platform: string
          status: string
          updated_at: string
          url: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          display_order?: number
          icon?: string | null
          id?: string
          member_count?: string | null
          name: string
          platform?: string
          status?: string
          updated_at?: string
          url: string
        }
        Update: {
          created_at?: string
          description?: string | null
          display_order?: number
          icon?: string | null
          id?: string
          member_count?: string | null
          name?: string
          platform?: string
          status?: string
          updated_at?: string
          url?: string
        }
        Relationships: []
      }
      daily_tasks: {
        Row: {
          completed_at: string
          id: string
          points_earned: number
          task_type: string
          user_id: string
        }
        Insert: {
          completed_at?: string
          id?: string
          points_earned?: number
          task_type: string
          user_id: string
        }
        Update: {
          completed_at?: string
          id?: string
          points_earned?: number
          task_type?: string
          user_id?: string
        }
        Relationships: []
      }
      fpc_codes: {
        Row: {
          code: string
          created_at: string
          id: string
          payment_id: string
          used: boolean
          used_at: string | null
          used_for_withdrawal_id: string | null
          user_id: string
        }
        Insert: {
          code: string
          created_at?: string
          id?: string
          payment_id: string
          used?: boolean
          used_at?: string | null
          used_for_withdrawal_id?: string | null
          user_id: string
        }
        Update: {
          code?: string
          created_at?: string
          id?: string
          payment_id?: string
          used?: boolean
          used_at?: string | null
          used_for_withdrawal_id?: string | null
          user_id?: string
        }
        Relationships: []
      }
      payment_account_audit: {
        Row: {
          action: string
          admin_id: string
          admin_name: string | null
          created_at: string
          id: string
          new_values: Json | null
          payment_account_id: string | null
          previous_values: Json | null
        }
        Insert: {
          action: string
          admin_id: string
          admin_name?: string | null
          created_at?: string
          id?: string
          new_values?: Json | null
          payment_account_id?: string | null
          previous_values?: Json | null
        }
        Update: {
          action?: string
          admin_id?: string
          admin_name?: string | null
          created_at?: string
          id?: string
          new_values?: Json | null
          payment_account_id?: string | null
          previous_values?: Json | null
        }
        Relationships: []
      }
      payment_accounts: {
        Row: {
          account_name: string
          account_number: string
          bank_name: string
          created_at: string
          id: string
          is_default: boolean
          payment_method: string
          qr_code: string | null
          status: boolean
          updated_at: string
        }
        Insert: {
          account_name: string
          account_number: string
          bank_name: string
          created_at?: string
          id?: string
          is_default?: boolean
          payment_method?: string
          qr_code?: string | null
          status?: boolean
          updated_at?: string
        }
        Update: {
          account_name?: string
          account_number?: string
          bank_name?: string
          created_at?: string
          id?: string
          is_default?: boolean
          payment_method?: string
          qr_code?: string | null
          status?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      payments: {
        Row: {
          amount: number
          created_at: string
          id: string
          receipt_url: string | null
          reviewed_at: string | null
          status: string
          user_id: string
        }
        Insert: {
          amount?: number
          created_at?: string
          id?: string
          receipt_url?: string | null
          reviewed_at?: string | null
          status?: string
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          id?: string
          receipt_url?: string | null
          reviewed_at?: string | null
          status?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          bonus_balance: number
          created_at: string
          full_name: string
          id: string
          level: string
          phone: string | null
          referral_code: string | null
          referred_by: string | null
          telegram_join_completed: boolean
          total_tasks_completed: number
          updated_at: string
          user_id: string
          username: string
        }
        Insert: {
          bonus_balance?: number
          created_at?: string
          full_name?: string
          id?: string
          level?: string
          phone?: string | null
          referral_code?: string | null
          referred_by?: string | null
          telegram_join_completed?: boolean
          total_tasks_completed?: number
          updated_at?: string
          user_id: string
          username?: string
        }
        Update: {
          bonus_balance?: number
          created_at?: string
          full_name?: string
          id?: string
          level?: string
          phone?: string | null
          referral_code?: string | null
          referred_by?: string | null
          telegram_join_completed?: boolean
          total_tasks_completed?: number
          updated_at?: string
          user_id?: string
          username?: string
        }
        Relationships: [
          {
            foreignKeyName: "profiles_referred_by_fkey"
            columns: ["referred_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      referrals: {
        Row: {
          created_at: string
          id: string
          referee_profile_id: string
          referee_user_id: string
          referrer_profile_id: string
          reward_amount: number
          status: string
        }
        Insert: {
          created_at?: string
          id?: string
          referee_profile_id: string
          referee_user_id: string
          referrer_profile_id: string
          reward_amount?: number
          status?: string
        }
        Update: {
          created_at?: string
          id?: string
          referee_profile_id?: string
          referee_user_id?: string
          referrer_profile_id?: string
          reward_amount?: number
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "referrals_referee_profile_id_fkey"
            columns: ["referee_profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "referrals_referrer_profile_id_fkey"
            columns: ["referrer_profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      spin_history: {
        Row: {
          amount: number
          id: string
          spun_at: string
          user_id: string
        }
        Insert: {
          amount?: number
          id?: string
          spun_at?: string
          user_id: string
        }
        Update: {
          amount?: number
          id?: string
          spun_at?: string
          user_id?: string
        }
        Relationships: []
      }
      transactions: {
        Row: {
          amount: number
          created_at: string
          description: string | null
          id: string
          metadata: Json | null
          type: string
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          description?: string | null
          id?: string
          metadata?: Json | null
          type: string
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          description?: string | null
          id?: string
          metadata?: Json | null
          type?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      welcome_bonus_claims: {
        Row: {
          amount: number
          created_at: string
          id: string
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          id?: string
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          id?: string
          user_id?: string
        }
        Relationships: []
      }
      withdrawal_requests: {
        Row: {
          account_name: string
          account_number: string
          amount: number
          approved_at: string | null
          bank_name: string
          created_at: string
          fpc_code: string | null
          id: string
          rejection_reason: string | null
          reviewed_at: string | null
          status: string
          user_id: string
          withdrawal_code: string | null
        }
        Insert: {
          account_name: string
          account_number: string
          amount: number
          approved_at?: string | null
          bank_name: string
          created_at?: string
          fpc_code?: string | null
          id?: string
          rejection_reason?: string | null
          reviewed_at?: string | null
          status?: string
          user_id: string
          withdrawal_code?: string | null
        }
        Update: {
          account_name?: string
          account_number?: string
          amount?: number
          approved_at?: string | null
          bank_name?: string
          created_at?: string
          fpc_code?: string | null
          id?: string
          rejection_reason?: string | null
          reviewed_at?: string | null
          status?: string
          user_id?: string
          withdrawal_code?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admin_create_fpc_code: {
        Args: { p_code: string; p_payment_id: string; p_user_id: string }
        Returns: string
      }
      admin_create_payment_account: {
        Args: {
          p_account_name: string
          p_account_number: string
          p_bank_name: string
          p_is_default: boolean
          p_payment_method: string
          p_qr_code: string
          p_status: boolean
        }
        Returns: string
      }
      admin_delete_fpc_code: { Args: { p_id: string }; Returns: undefined }
      admin_delete_payment_account: {
        Args: { p_id: string }
        Returns: undefined
      }
      admin_generate_fpc_code: { Args: never; Returns: string }
      admin_regenerate_fpc_code: { Args: { p_id: string }; Returns: string }
      admin_reset_telegram_join: {
        Args: { p_profile_id: string }
        Returns: undefined
      }
      admin_set_default_payment_account: {
        Args: { p_id: string }
        Returns: undefined
      }
      admin_toggle_fpc_used: {
        Args: { p_id: string; p_used: boolean }
        Returns: undefined
      }
      admin_update_payment: {
        Args: {
          p_amount: number
          p_id: string
          p_receipt_url: string
          p_status: string
        }
        Returns: undefined
      }
      admin_update_payment_account: {
        Args: {
          p_account_name: string
          p_account_number: string
          p_bank_name: string
          p_id: string
          p_is_default: boolean
          p_payment_method: string
          p_qr_code: string
          p_status: boolean
        }
        Returns: undefined
      }
      admin_update_payment_status: {
        Args: { p_id: string; p_status: string }
        Returns: undefined
      }
      admin_update_setting: {
        Args: { p_key: string; p_value: string }
        Returns: undefined
      }
      admin_update_user_profile: {
        Args: { p_balance: number; p_level: string; p_profile_id: string }
        Returns: undefined
      }
      admin_update_withdrawal: {
        Args: {
          admin_user_id: string
          new_status: string
          reason?: string
          withdrawal_id: string
        }
        Returns: undefined
      }
      admin_update_withdrawal_account: {
        Args: {
          p_account_name: string
          p_account_number: string
          p_bank: string
          p_id: string
        }
        Returns: undefined
      }
      claim_welcome_bonus: { Args: never; Returns: Json }
      complete_telegram_join: { Args: never; Returns: undefined }
      generate_fpc_code: { Args: never; Returns: string }
      generate_referral_code: { Args: never; Returns: string }
      generate_withdrawal_code: { Args: never; Returns: string }
      get_active_payment_account: {
        Args: never
        Returns: {
          account_name: string
          account_number: string
          bank_name: string
          is_default: boolean
          payment_method: string
          qr_code: string
          status: boolean
        }[]
      }
      get_admin_display_name: { Args: { _uid: string }; Returns: string }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_current_user_admin: { Args: never; Returns: boolean }
      is_current_user_super_admin: { Args: never; Returns: boolean }
      lookup_referrer_id: { Args: { p_code: string }; Returns: string }
      process_referral: {
        Args: { new_user_id: string; referrer_code: string }
        Returns: undefined
      }
    }
    Enums: {
      app_role: "admin" | "moderator" | "user" | "super_admin"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "moderator", "user", "super_admin"],
    },
  },
} as const
